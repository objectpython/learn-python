'''
    Class: MyCalculator
    Description: Purpose of this class is to functionality of basic mathematical operations for calculator application
    Application currently supports addition, subtraction , multiplication and division operation of integer numbers
    upto 6 digits.

    Author: Sameer Soundankar
    Ver:    1
'''
import tkinter as tk
import re

class MyCalculator:
    MAX_DIGITS = 6
    LIMITED_SUPPORT_MSG = "Ver 1: Limited Support: Numbers upto 6 digits are allowed."
    NORMAL_MSG = "Simple Calculator. Version 1:"

    def __init__(self,entBox, messageBox):
        self.digit = 0
        self.ent_box = entBox
        self.msg = messageBox
        self.is_calculated = False

    def calculate(self):
        self.msg.config(text=MyCalculator.NORMAL_MSG)
        current_val = self.ent_box.get()

        values = current_val.split(operator)

        if len(values) == 2 and values[0]!="":
            self.is_calculated = True
            self.ent_box.delete(0, tk.END)
            num1 = int(values[0])
            num2 = int(values[1])

            try:
                if operator == "+":
                    self.ent_box.insert(0, (num1 + num2))
                elif operator == "-":
                    self.ent_box.insert(0, (num1 - num2))
                elif operator == "*":
                    self.ent_box.insert(0, (num1 * num2))
                elif operator == "/":
                    self.ent_box.insert(0, (num1 / num2))
            except:
                self.ent_box.insert(0, "ERROR")

    def btn_op(self,op):
        self.msg.config(text=MyCalculator.NORMAL_MSG)
        self.digit = 0
        global operator
        current_val = self.ent_box.get()
        if (not self.is_calculated) and current_val!= "ERROR" and current_val != "":
            operator = op
            self.ent_box.delete(0, tk.END)

            is_operator_present = re.search("[+-/*]", current_val)
            if is_operator_present != None:
                result = re.sub("[+-/*]", op, current_val)
                self.ent_box.insert(0, result)
            else:
                self.ent_box.insert(0, current_val + op)
        elif self.is_calculated:
            self.msg.config(text="Calculation Completed. Input new numbers.")

    def btn_click(self,num):
        self.digit = self.digit  + 1
        if self.digit <= MyCalculator.MAX_DIGITS:
            if self.is_calculated == True:
                self.ent_box.delete(0, tk.END)
                self.is_calculated = False

            current_val = self.ent_box.get()
            self.ent_box.delete(0, tk.END)
            if current_val != "ERROR":
                self.ent_box.insert(0, current_val + num)
            else:
                self.ent_box.insert(0, num)
        else:
            self.msg.config(text=MyCalculator.LIMITED_SUPPORT_MSG)

    def clear(self):
        self.digit = 0
        self.ent_box.delete(0, tk.END)
        self.msg.config(text=MyCalculator.NORMAL_MSG)

    def backspace(self):
        self.msg.config(text=MyCalculator.NORMAL_MSG)
        if self.is_calculated == False:
            current_val = self.ent_box.get()
            self.ent_box.delete(0, tk.END)
            self.ent_box.insert(0, current_val.strip(current_val[len(current_val) - 1]))
            self.digit = self.digit -1