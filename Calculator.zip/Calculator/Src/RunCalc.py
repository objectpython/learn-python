import MyCalcGUI

calc = MyCalcGUI.MyCalcGUI()
calc.launch()