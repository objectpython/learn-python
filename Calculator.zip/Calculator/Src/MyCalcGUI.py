'''
    Class: MyCalcGUI
    Description: Purpose of this class is to create user interface for calculator application
    Author: Sameer Soundankar
    Ver:    1
'''
from MyCalculator import *

class MyCalcGUI:
    NORMAL_MSG = "Simple Calculator. Version 1:"
    def __createUIElements(self):
        win = self.win
        win.title("Simple Calculator")
        win.geometry("370x600")

        ent_font = ("Arial", 28)
        btn_font = ("Arial", 14)
        error_font = ("Arial", 8)
        ent_box = tk.Entry(win, width=16, borderwidth=5, font=ent_font, justify="right")
        ent_box.grid(row=0, column=0, columnspan=4, padx=10, pady=10)
        self.msg = tk.Message(win, text=MyCalcGUI.NORMAL_MSG, width = 350, font=error_font, fg="red")
        mc = MyCalculator(ent_box,self.msg)

        # Create UI elements
        self.btn1 = tk.Button(win, text="1", command=lambda: mc.btn_click('1'), font=btn_font)
        self.btn2 = tk.Button(win, text="2", command=lambda: mc.btn_click('2'), font=btn_font)
        self.btn3 = tk.Button(win, text="3", command=lambda: mc.btn_click('3'), font=btn_font)
        self.btn4 = tk.Button(win, text="4", command=lambda: mc.btn_click('4'), font=btn_font)
        self.btn5 = tk.Button(win, text="5", command=lambda: mc.btn_click('5'), font=btn_font)
        self.btn6 = tk.Button(win, text="6", command=lambda: mc.btn_click('6'), font=btn_font)
        self.btn7 = tk.Button(win, text="7", command=lambda: mc.btn_click('7'), font=btn_font)
        self.btn8 = tk.Button(win, text="8", command=lambda: mc.btn_click('8'), font=btn_font)
        self.btn9 = tk.Button(win, text="9", command=lambda: mc.btn_click('9'), font=btn_font)
        self.btn0 = tk.Button(win, text="0", command=lambda: mc.btn_click('0'), font=btn_font)

        self.btn_add = tk.Button(win, text="+", command=lambda: mc.btn_op('+'), font=btn_font)
        self.btn_sub = tk.Button(win, text="-", command=lambda: mc.btn_op('-'), font=btn_font)
        self.btn_mul = tk.Button(win, text="*", command=lambda: mc.btn_op('*'), font=btn_font)
        self.btn_divide = tk.Button(win, text="/", command=lambda: mc.btn_op('/'), font=btn_font)

        self.btn_result = tk.Button(win, text="=", command=mc.calculate, font=btn_font)
        self.btn_clear = tk.Button(win, text="C", command=mc.clear, font=btn_font)
        self.btn_bksp = tk.Button(win, text="BkSp", command=mc.backspace, font=btn_font)


    def __arrangeGUI(self):
        std_btn_width = 80
        std_btn_height = 80
        std_btn_ht = 80
        spacing = 10

        row1_yaxis = std_btn_height
        row2_yaxis = row1_yaxis + std_btn_ht + spacing
        row3_yaxis = row2_yaxis + std_btn_ht + spacing
        row4_yaxis = row3_yaxis + std_btn_ht + spacing
        row5_yaxis = row4_yaxis + std_btn_ht + spacing
        row6_yaxis = row5_yaxis + std_btn_ht + spacing

        col1_xaxis = spacing
        col2_xaxis = col1_xaxis + std_btn_width + spacing
        col3_xaxis = col2_xaxis + std_btn_width + spacing
        col4_xaxis = col3_xaxis + std_btn_width + spacing

        self.btn_clear.place(x=col1_xaxis, y=row1_yaxis, width=2 * std_btn_width + spacing, height=std_btn_height)
        self.btn_bksp.place(x=190, y=row1_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn_divide.place(x=280, y=row1_yaxis, width=std_btn_width, height=std_btn_height)

        self.btn7.place(x=col1_xaxis, y=row2_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn8.place(x=col2_xaxis, y=row2_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn9.place(x=col3_xaxis, y=row2_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn_mul.place(x=col4_xaxis, y=row2_yaxis, width=std_btn_width, height=std_btn_height)

        self.btn4.place(x=col1_xaxis, y=row3_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn5.place(x=col2_xaxis, y=row3_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn6.place(x=col3_xaxis, y=row3_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn_sub.place(x=col4_xaxis, y=row3_yaxis, width=std_btn_width, height=std_btn_height)

        self.btn1.place(x=col1_xaxis, y=row4_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn2.place(x=col2_xaxis, y=row4_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn3.place(x=col3_xaxis, y=row4_yaxis, width=std_btn_width, height=std_btn_height)
        self.btn_add.place(x=col4_xaxis, y=row4_yaxis, width=std_btn_width, height=std_btn_height)

        self.btn0.place(x=col1_xaxis, y=row5_yaxis, width=2 * (std_btn_width) + spacing, height=std_btn_height)
        self.btn_result.place(x=col3_xaxis, y=row5_yaxis, width=2 * (std_btn_width) + spacing, height=std_btn_height)

        self.msg.place(x=col1_xaxis, y=row6_yaxis, width=4 * (std_btn_width) + spacing, height=std_btn_height)
    def __init__(self):
            self.win = tk.Tk()
            self.__createUIElements()
            self.__arrangeGUI()

    def launch(self):
        self.win.mainloop()



